package lucasgenovez.lucasgenovez.organizze.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import lucasgenovez.lucasgenovez.organizze.R;

public class ReceitasActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receitas);
    }
}
